void
enable_port(int port, int protocol){
  return;
}

void
done_with_port(int port, int protocol) {
  return;
}
